(function() {
var toc =  [{"type":"item","name":"Task-CLI: Installing Command Line Tools","url":"PolarisDemo/Tasks/Task-CLI_Installing_Command_Line_Tools.htm"},{"type":"item","name":"Task-CLI: Perform CLI Scan on Project","url":"PolarisDemo/Tasks/Task-CLI_Perform_CLI_Scan_on_Project.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
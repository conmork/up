(function() {
var toc =  [{"type":"item","name":"Tool agnostic","url":"PolarisDemo/Workflows/Customization_and_extensibility1.htm#TOC_Tool_agnostic1bc-1"},{"type":"item","name":"Customizable API","url":"PolarisDemo/Workflows/Customizable_API1.htm"},{"type":"item","name":"CI/CD approaches","url":"PolarisDemo/Workflows/CI_CD_approaches1.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
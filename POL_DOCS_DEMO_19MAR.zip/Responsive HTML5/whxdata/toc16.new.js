(function() {
var toc =  [{"type":"item","name":"Release Notes","url":"PolarisDemo/Resources/Release_Notes.htm"},{"type":"item","name":"Compatibility and Support","url":"PolarisDemo/Resources/Compatibility_and_Support.htm"},{"type":"item","name":"Additional Resources","url":"PolarisDemo/Resources/Additional_Resources.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
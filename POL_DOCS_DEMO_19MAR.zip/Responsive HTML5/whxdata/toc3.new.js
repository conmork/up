(function() {
var toc =  [{"type":"item","name":"Architecture and the parts of Polaris:","url":"PolarisDemo/Overview/Deploying_and_Using_Polaris.htm#TOC_Architecture_and_thebc-1"},{"type":"item","name":"Use cases","url":"PolarisDemo/Overview/Use_cases.htm"},{"type":"item","name":"Roles","url":"PolarisDemo/Overview/Roles.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
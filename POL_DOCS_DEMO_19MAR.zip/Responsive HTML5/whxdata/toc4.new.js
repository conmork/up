(function() {
var toc =  [{"type":"item","name":"Tool agnostic","url":"PolarisDemo/Overview/Customization_and_extensibility.htm#TOC_Tool_agnosticbc-1"},{"type":"item","name":"Customizable API","url":"PolarisDemo/Overview/Customizable_API.htm"},{"type":"item","name":"CI/CD approaches","url":"PolarisDemo/Overview/CI_CD_approaches.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
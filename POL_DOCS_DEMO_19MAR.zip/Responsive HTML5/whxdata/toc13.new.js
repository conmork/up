(function() {
var toc =  [{"type":"item","name":"Polaris Administration Tasks","url":"PolarisDemo/Tasks/Polaris_Administration_Tasks.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
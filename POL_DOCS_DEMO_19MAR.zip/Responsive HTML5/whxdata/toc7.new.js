(function() {
var toc =  [{"type":"book","name":"Web Interface","key":"toc8","url":"PolarisDemo/Tasks/Web_Interface.htm"},{"type":"book","name":"Administration","key":"toc13","url":"PolarisDemo/Tasks/Administration.htm"},{"type":"book","name":"CLI","key":"toc14","url":"PolarisDemo/Tasks/CLI.htm"},{"type":"book","name":"API","key":"toc15","url":"PolarisDemo/Tasks/API.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
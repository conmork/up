(function() {
var toc =  [{"type":"item","name":"Task-JP: Configure Jira Exports for a Project","url":"PolarisDemo/Web_Interface/Task-JP_Configure_Jira_Exports_for_a_Project.htm"},{"type":"item","name":"Task-JP: Export an Issue to Jira","url":"PolarisDemo/Web_Interface/Task-JP_Export_an_Issue_to_Jira.htm"},{"type":"item","name":"Task-JP: Export Multiple Issues to Jira","url":"PolarisDemo/Web_Interface/Task-JP_Export_Multiple_Issues_to_Jira.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"Additional Resources","last":"Workflows","num":"42","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
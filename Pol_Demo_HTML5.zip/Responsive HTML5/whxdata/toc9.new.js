(function() {
var toc =  [{"type":"item","name":"Task-AR: Creating a Customized Report","url":"PolarisDemo/Web_Interface/Task-AR_Creating_a_Customized_Report.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
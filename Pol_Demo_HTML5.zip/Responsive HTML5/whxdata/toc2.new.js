(function() {
var toc =  [{"type":"item","name":"What Polaris does","url":"PolarisDemo/Overview/What_is_Polaris.htm#TOC_What_Polaris_doesbc-1"},{"type":"item","name":"Problems Polaris solves","url":"PolarisDemo/Overview/Problems_Polaris_solves.htm"},{"type":"item","name":"Benefits of using Polaris","url":"PolarisDemo/Overview/Benefits_of_using_Polaris.htm"},{"type":"item","name":"What Polaris does not do","url":"PolarisDemo/Overview/What_Polaris_does_not_do.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
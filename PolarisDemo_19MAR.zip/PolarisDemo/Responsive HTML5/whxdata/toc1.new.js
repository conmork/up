(function() {
var toc =  [{"type":"book","name":"What is Polaris","key":"toc2","url":"PolarisDemo/Overview/What_is_Polaris.htm"},{"type":"book","name":"Deploying and Using Polaris","key":"toc3","url":"PolarisDemo/Overview/Deploying_and_Using_Polaris.htm"},{"type":"book","name":"Customization and extensibility","key":"toc4","url":"PolarisDemo/Overview/Customization_and_extensibility.htm"},{"type":"item","name":"Terminology","url":"PolarisDemo/Overview/Terminology.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
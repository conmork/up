(function() {
var toc =  [{"type":"book","name":"Overview","key":"toc1","url":"PolarisDemo/Overview/Overview.htm"},{"type":"book","name":"Workflows","key":"toc5","url":"PolarisDemo/Workflows/Workflows.htm"},{"type":"book","name":"Tasks","key":"toc7","url":"PolarisDemo/Tasks/Tasks.htm"},{"type":"book","name":"Resources","key":"toc16","url":"PolarisDemo/Resources/Resources.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
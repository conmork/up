(function() {
var toc =  [{"type":"item","name":"Task-AR: Creating a Customized Report","url":"PolarisDemo/Tasks/Generating_Application_Reports_AR.htm#TOC_Task_AR_Creating_abc-1"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
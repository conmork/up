(function() {
var toc =  [{"type":"item","name":"Task-JP: Configure Jira Exports for a Project","url":"PolarisDemo/Tasks/Using_Jira_with_Polaris_JP.htm#TOC_Task_JP_Configure_Jirabc-1"},{"type":"item","name":"Task-JP: Export an Issue to Jira","url":"PolarisDemo/Tasks/Using_Jira_with_Polaris_JP.htm#TOC_Task_JP_Export_an_Issuebc-2"},{"type":"item","name":"Task-JP: Export Multiple Issues to Jira","url":"PolarisDemo/Tasks/Using_Jira_with_Polaris_JP.htm#TOC_Task_JP_Export_Multiplebc-3"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();